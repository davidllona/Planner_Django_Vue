from django.contrib import admin
from .models import *

admin.site.register(Task)
admin.site.register(Period)

# Register your models here.


